//Application.hpp


class TApplication{};


class  TWindow:TApplication{};


class TMemo:TWindow{};


class TCaption:TWindow{};


class TEdit:TWindow{};



