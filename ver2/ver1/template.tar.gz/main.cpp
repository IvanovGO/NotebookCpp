//main.cpp

#include "main.hpp"

int main(int argc, char * argv[]){

TApplication app;

}
